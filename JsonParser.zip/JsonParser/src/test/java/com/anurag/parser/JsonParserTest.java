/**
 * 
 */
package com.anurag.parser;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

/**
 * @author 91935
 *
 */
public class JsonParserTest {
	
	//Original question
	@Test
	public void testEmbeddedJson() throws JsonMappingException, JsonProcessingException {
		JsonParserApplication parserTest=new JsonParserApplication();
		String givenJson = "{\r\n"
				+ "  \"k1\": \"v1\",\r\n"
				+ "  \"k2\": [\r\n"
				+ "    \"v2\",\r\n"
				+ "    \"v3\",\r\n"
				+ "    \"\",\r\n"
				+ "    {\r\n"
				+ "      \"k21\": \"v21\",\r\n"
				+ "      \"k22\": \"\"\r\n"
				+ "    }\r\n"
				+ "  ],\r\n"
				+ "  \"k3\": {\r\n"
				+ "    \"k4\": \"v4\",\r\n"
				+ "    \"k5\": [\r\n"
				+ "      \"v5\",\r\n"
				+ "      \"v6\",\r\n"
				+ "      null\r\n"
				+ "    ],\r\n"
				+ "    \"k6\": {\r\n"
				+ "      \"k7\": \"v7\",\r\n"
				+ "      \"k8\": \"\"\r\n"
				+ "    }\r\n"
				+ "  },\r\n"
				+ "  \"k9\": [],\r\n"
				+ "  \"k10\": null,\r\n"
				+ "  \"k11\": [\r\n"
				+ "    23,\r\n"
				+ "    true,\r\n"
				+ "    false,\r\n"
				+ "    \"hello\"\r\n"
				+ "  ]\r\n"
				+ "}";
		System.out.println("Given Json is : " + givenJson);
		String expectedJson="{\"k1\":\"v1\",\"k2\":[\"v2\",\"v3\",{\"k21\":\"v21\"}],\"k3\":{\"k4\":\"v4\",\"k5\":[\"v5\",\"v6\"],\"k6\":{\"k7\":\"v7\"}},\"k11\":[23,true,false,\"hello\"]}";
		String normalizedJson=parserTest.parseJson(givenJson);
		System.out.println("Normalized json is :" + normalizedJson);
		assertEquals(expectedJson, normalizedJson);
		
	}
	
	@Test
	public void testJsonWhenArrayisNull() throws JsonMappingException, JsonProcessingException {
		JsonParserApplication parserTest=new JsonParserApplication();
		String givenJson = "{\"k5\":[\"v5\",\"v6\",null]}";
		String expectedJson="{\"k5\":[\"v5\",\"v6\"]}";
		String normalizedJson=parserTest.parseJson(givenJson);
		assertEquals(expectedJson, normalizedJson);
		
	}
	
	@Test
	public void testJsonWhenNodeisNull() throws JsonMappingException, JsonProcessingException {
		JsonParserApplication parserTest=new JsonParserApplication();
		String givenJson = " {\r\n" + " \"k10\":null\r\n" + " }";
		String expectedJson="{}";
		String normalizedJson=parserTest.parseJson(givenJson);
		assertEquals(expectedJson, normalizedJson);
		
	}
	
	@Test
	public void testJsonWhenNodeHavingBlankArray() throws JsonMappingException, JsonProcessingException {
		JsonParserApplication parserTest=new JsonParserApplication();
		
		String givenJson=" {\r\n"
				+ " \"k9\":[]\r\n"
				+ " }";
		String expectedJson="{}";
		String normalizedJson=parserTest.parseJson(givenJson);
		
		assertEquals(expectedJson, normalizedJson);
		
	}
	
	@Test
	public void testJsonWhenNodeArrayOfObject() throws JsonMappingException, JsonProcessingException {
		JsonParserApplication parserTest=new JsonParserApplication();
		String givenJson = "{ \"k2\":[\"v2\",{\"k21\":\"v21\",\"k22\":\"\"}] }";
		
		String expectedJson="{\"k2\":[\"v2\",{\"k21\":\"v21\"}]}";
		String normalizedJson=parserTest.parseJson(givenJson);
	
		assertEquals(expectedJson, normalizedJson);
		
	}
	
	@Test
	public void testForEmbeddedJson() throws JsonMappingException, JsonProcessingException {
		
		JsonParserApplication parserTest=new JsonParserApplication();
		
		String givenJson="{\r\n"
				+ "  \"k1\": \"v1\",\r\n"
				+ "  \"k2\": [\r\n"
				+ "    \"v2\",\r\n"
				+ "    \"v3\",\r\n"
				+ "    \"\",\r\n"
				+ "    {\r\n"
				+ "      \"k21\": \"v21\",\r\n"
				+ "      \"k22\": \"\"\r\n"
				+ "    },\r\n"
				+ "	   {\r\n"
				+ "      \"k23\": \"v23\",\r\n"
				+ "      \"k22\": \"\"\r\n"
				+ "    }\r\n"
				+ "  ],\r\n"
				+ "  \"k3\": {\r\n"
				+ "    \"k4\": \"v4\",\r\n"
				+ "    \"k5\": [\r\n"
				+ "      \"v5\",\r\n"
				+ "      \"v6\",\r\n"
				+ "      null\r\n"
				+ "    ],\r\n"
				+ "    \"k6\": {\r\n"
				+ "      \"k7\": \"v7\",\r\n"
				+ "      \"k8\": \"\"\r\n"
				+ "    }\r\n"
				+ "  },\r\n"
				+ "  \"k9\": [],\r\n"
				+ "  \"k10\": null,\r\n"
				+ "  \"k11\": [\r\n"
				+ "    23,\r\n"
				+ "    true,\r\n"
				+ "    false,\r\n"
				+ "    \"hello\"\r\n"
				+ "  ]\r\n"
				+ "}";
		
		String expectedJson="{\"k1\":\"v1\",\"k2\":[\"v2\",\"v3\",{\"k21\":\"v21\"},{\"k23\":\"v23\"}],\"k3\":{\"k4\":\"v4\",\"k5\":[\"v5\",\"v6\"],\"k6\":{\"k7\":\"v7\"}},\"k11\":[23,true,false,\"hello\"]}";
		String normalizedJson=parserTest.parseJson(givenJson);
		assertEquals(expectedJson, normalizedJson);
		
	}
	
	

}
