package com.anurag.parser;

import java.util.Iterator;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;


/**
 * @author 91935
 *  Parser class to Normalize Dynamic Unstructured JSON array by rmoving null , blank and ""
 *
 */

public class JsonParserApplication {
	
	private ObjectMapper mapper;

	public static void main(String[] args) throws JsonMappingException, JsonProcessingException {
		JsonParserApplication parser = new JsonParserApplication();
		String data = "{\r\n" + "  \"k1\": \"v1\",\r\n" + "  \"k2\": [\r\n" + "    \"v2\",\r\n"
				+ "    \"v3\",\r\n" + "    \"\",\r\n" + "    {\r\n" + "      \"k21\": \"v21\",\r\n"
				+ "      \"k22\": \"\"\r\n" + "    }\r\n" + "  ],\r\n" + "  \"k3\": {\r\n" + "    \"k4\": \"v4\",\r\n"
				+ "    \"k5\": [\r\n" + "      \"v5\",\r\n" + "      \"v6\",\r\n" + "      null\r\n" + "    ],\r\n"
				+ "    \"k6\": {\r\n" + "      \"k7\": \"v7\",\r\n" + "      \"k8\": \"\"\r\n" + "    }\r\n"
				+ "  },\r\n" + "  \"k9\": [],\r\n" + "  \"k10\": null,\r\n" + "  \"k11\": [\r\n" + "    23,\r\n"
				+ "    true,\r\n" + "    false,\r\n" + "    \"hello\"\r\n" + "  ]\r\n" + "}";
		String normalizedData =parser.parseJson(data);
		System.out.println(normalizedData);
	}

	public String parseJson(String json) throws JsonMappingException, JsonProcessingException {

		JsonNode rootNode = getRootNode(json);
		processNode(rootNode);
		return mapper.writeValueAsString(rootNode);

	}

	/**
	 * @author 91935
	 * Process all Nodes recursively
	 */

	public static JsonNode processNode(JsonNode node) {

		Iterator<JsonNode> iterator = node.elements();

		while (iterator.hasNext()) {
			JsonNode childNode = iterator.next();

			if ((childNode instanceof TextNode || childNode instanceof NullNode) && isEmpty(childNode.textValue())) {
					iterator.remove();
				
			} 
			else if (childNode instanceof ObjectNode) {
				processNode(childNode);
			}
			else if (childNode instanceof ArrayNode ) {
				     if(childNode.isEmpty()) {
				    	 iterator.remove();
				     }
				     else {
				    	 processNode(childNode);
				     }
				   
			}
		}

		return node;

	}
	
	private JsonNode getRootNode(String json) throws JsonMappingException, JsonProcessingException {

		mapper = new ObjectMapper(new JsonFactory());
		return mapper.readTree(json);
	}

	/**
	 * @author 91935
	 * Empty or Null String Check
	 */
	private static boolean isEmpty(String str) {
		return str == null || str.trim().isEmpty();
	}
}
